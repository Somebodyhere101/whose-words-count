#!/bin/bash
# Second-family replication: OLMo-2-7B-Instruct (32 layers -> 6, 15) and Granite-3.3-8B-Instruct (40 layers -> 8, 18).
export HF_HOME=/root/hf
mkdir -p /root/hf
cd /workspace/agp/code
pip install -q "transformers==5.16.1" accelerate
for spec in "allenai/OLMo-2-1124-7B-Instruct 6,15" "ibm-granite/granite-3.3-8b-instruct 8,18"; do
  set -- $spec; M=$1; L=$2; T=$(basename $M)
  python -c "from huggingface_hub import snapshot_download; snapshot_download('$M'); print('downloaded $M')"
  python -u agp_fast.py --model $M --conds 1,gF,oF,gN,oN,gW,oW --seeds 300-339 --batch 16 --out ../out_fast_$T 2>&1 | grep -v -i warn
  python -u src_probe.py --model $M --n 240 --out ../out_stage2_$T 2>&1 | grep -v -i warn
  python -u steer_run.py --model $M --cells gF,oF --dirs ../out_stage2_$T/directions.pt --layers $L --batch 16 --out ../out_stage3_$T
  python -u steer_run.py --model $M --cells gW,oW --dirs ../out_stage2_$T/directions.pt --layers $L --batch 16 --out ../out_stage3w_$T
  rm -rf /root/hf/hub/models--$(echo $M | sed 's#/#--#')
done
echo CLOUD6_DONE
